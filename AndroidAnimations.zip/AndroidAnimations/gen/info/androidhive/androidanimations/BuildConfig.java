/** Automatically generated file. DO NOT MODIFY */
package info.androidhive.androidanimations;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}